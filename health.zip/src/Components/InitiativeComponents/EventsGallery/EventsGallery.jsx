import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import style from "./EventsGallery.module.scss";
import Lightbox from "yet-another-react-lightbox";
import "yet-another-react-lightbox/styles.css";
import Fullscreen from "yet-another-react-lightbox/plugins/fullscreen";
import Slideshow from "yet-another-react-lightbox/plugins/slideshow";
import { Grid, Navigation, Pagination } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css/bundle";
import "./EventsGallery.css";

export default function EventsGallery({ events }) {
  const [t, i18n] = useTranslation();
  const [open, setOpen] = useState(false);


  // const srcs = events.map(function (event) {
  //   console.log(event);
  //   return {src: event.}
  // });
  return (
    <>
      <div>
        {events?.map((item, index) => (
          <div className="row" key={index}>
            <div className="col-lg-4">
              <div className={`${style.eventImg}`}>
                <img src={item.cardImage} alt="event" />
              </div>
            </div>
            <div className="col-lg-8">
              <div className={`${style.eventInfo}`}>
                <h3>{item.sectionTitle}</h3>
                <div className={`${style.eventBtn}`}>
                  <button className={`${style.one} btn btn-primary`}>
                    {item.btn1Text}
                    {i18n.language === "en" && (
                      <i className="fa-solid fa-chevron-right"></i>
                    )}
                    {i18n.language === "ar" && (
                      <i className="fa-solid fa-chevron-left"></i>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>



      <div className="PhotoImg">
        <Swiper
          breakpoints={{
            360: {
              width: 360,
              slidesPerView: 1,
              grid: {
                rows: 2,
                fill: "row",
              },
            },
            768: {
              width: 768,
              slidesPerView: 1,
              grid: {
                rows: 2,
                fill: "row",
              },
            },
            769: {
              width: 769,
              slidesPerView: 1,
              grid: {
                rows: 2,
                fill: "row",
              },
            },
            1280: {
              width: 1280,
              slidesPerView: 3,
              grid: {
                rows: 2,
                fill: "row",
              },
            },
          }}
          spaceBetween={30}
          pagination={{
            clickable: true,
          }}
          modules={[Grid, Pagination, Navigation]}
          className="mySwiper"
        >
          {events?.images?.map((item, index) => (
            <SwiperSlide onClick={() => setOpen(true)} key={index}>
              <img src={item} alt="event" />
            </SwiperSlide>
          ))}
        </Swiper>
        {/* <Lightbox
          open={open}
          close={() => setOpen(false)}
          slides={[
            { src: `${events[0].images[0]}` },
            { src: `${events[1].images[1]}` },
            { src: `${events[2].images[2]}` },
            { src: `${events[3].images[3]}` },
            { src: `${events[4].images[4]}` },
            { src: `${events[5].images[5]}` },
          ]}
          plugins={[Fullscreen, Slideshow]}
        /> */}
      </div>
    </>
  );
}
